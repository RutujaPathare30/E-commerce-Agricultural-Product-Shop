<?php include('navbar.php'); ?>
          
    <div class="container mt-3">
        <h1 class="text-center">Holticulutre Seed</h1>
        <!-- Nav tabs -->
        <ul class="nav nav-tabs" role="tablist">
            <li class="nav-item">
                <a class="nav-link active" data-bs-toggle="tab" href="#mobiles">Vegetable Seed</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" data-bs-toggle="tab" href="#accessories">Flower Seed </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" data-bs-toggle="tab" href="#glass">Fruit Seed</a>
            </li>
            
        </ul>
        <!-- Tab panes -->
        <div class="tab-content">
            <div id="mobiles" class="container tab-pane active">
                <h3 class="text-center mt-2">Vegetable Seed</h3>
                <div class="row">
                    <div class="col-md-3 col-sm-6 mb-sm-3">
                        <div class="card">
                            <img src="img/CORIANDAR-NS-SURABHI-500-GM.webp" class="card-img-top " style="height: 230px;" alt="..." >
                            <div class="card-body text-center">
                                <h5 class="card-title">SURABHI CORIANDER </h5>
                                <p>Namdhari</p>
                                <h6 class="card-subtitle mb-2 text-muted "><i class="fa fa-inr"></i>208/-<i class="fa fa-inr"></i><s>250</s></h6>
                                <p class="card-text ">
                                    Saved price<i class="fa fa-inr"></i>42</p>
                                    <p class="card-text ">
                                        Size:500gm</p>
                                <a class="btn btn-success" href="https://api.whatsapp.com/send?phone=7028926449&amp;"><i class="fa fa-whatsapp"></i> Order Now</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-6 mb-sm-3">
                        <div class="card">
                            <img src="img/Artboard1copy9-2_74935102-1631-474d-a28d-2d8cc032f166.webp" class="card-img-top " style="height: 230px;" alt="..." >
                            <div class="card-body text-center">
                                <h5 class="card-title">GS-10 PEA SEED </h5>
                                <p>UPL</p>
                                <h6 class="card-subtitle mb-2 text-muted "><i class="fa fa-inr "></i>392/-<i class="fa fa-inr"></i><s>520</s></h6>
                                <p class="card-text ">
                                    Saved price <i class="fa fa-inr"></i>128</p>
                                    <p class="card-text ">
                                        Size:500gm</p>
                                <a class="btn btn-success" href="https://api.whatsapp.com/send?phone=9156965861&amp;"><i class="fa fa-whatsapp"></i> Order Now</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-6 mb-sm-3">
                        <div class="card">
                            <img src="img/Artboard1copy7-6.webp" class="card-img-top " style="height: 200px;" alt="..." >
                            <div class="card-body text-center">
                                <h5 class="card-title">KATAHI BITTER GOURD SEEDS</h5>
                                <p>VNR</p>
                                <h6 class="card-subtitle mb-2 text-muted "><i class="fa fa-inr "></i>131/-<i class="fa fa-inr"></i><s>180</s></h6>
                                <p class="card-text ">
                                    Saved price <i class="fa fa-inr"></i>49</p>
                                    <p class="card-text ">
                                        Size :50gm</p>
                                <a class="btn btn-success" href="https://api.whatsapp.com/send?phone=9156965861&amp;"><i class="fa fa-whatsapp"></i> Order Now</a>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-md-3 col-sm-6 mb-sm-3">
                        <div class="card">
                            <img src="img/Syngenta-CFL-1522-Cauliflower-Seeds_720x720_c57ea807-37b5-4e2e-a8cc-7379f190e370.webp" class="card-img-top " style="height: 200px;" alt="..." >
                            <div class="card-body text-center">
                                <h5 class="card-title">CFL 1522 CAULIFLOWER SEEDS</h5>
                                <p>Syngenta</p>
                                <h6 class="card-subtitle mb-2 text-muted "><i class="fa fa-inr "></i>763/-<i class="fa fa-inr"></i><s>910</s></h6>
                                <p class="card-text ">
                                    Saved price <i class="fa fa-inr"></i>147</p>
                                    <p class="card-text ">
                                        Size:2000Seeds</p>
                                <a class="btn btn-success" href="https://api.whatsapp.com/send?phone=9156965861&amp;"><i class="fa fa-whatsapp"></i> Order Now</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-6 mb-sm-3">
                        <div class="card">
                            <img src="img/Sahoo.webp" class="card-img-top " style="height: 200px;" alt="..." >
                            <div class="card-body text-center">
                                <h5 class="card-title">SAAHO TOMATO SEEDS [TO-3251]</h5>
                                <p>Syngenta</p>
                                <h6 class="card-subtitle mb-2 text-muted "><i class="fa fa-inr "></i>1055/-<i class="fa fa-inr"></i><s>1450</s></h6>
                                <p class="card-text ">
                                    Saved price <i class="fa fa-inr"></i>395</p>
                                    <p class="card-text ">
                                        Size:2000Seeds</p>
                                <a class="btn btn-success" href="https://api.whatsapp.com/send?phone=9156965861&amp;"><i class="fa fa-whatsapp"></i> Order Now</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-6 mb-sm-3">
                        <div class="card">
                            <img src="img/simran brinjal.webp" class="card-img-top " style="height: 200px;" alt="..." >
                            <div class="card-body text-center">
                                <h5 class="card-title">SIMRAN BRINJAL SEEDS</h5>
                                <p>VNR</p>
                                <h6 class="card-subtitle mb-2 text-muted "><i class="fa fa-inr "></i>230/-<i class="fa fa-inr"></i><s>296</s></h6>
                                <p class="card-text ">
                                    Saved price <i class="fa fa-inr"></i>66</p>
                                    <p class="card-text ">
                                        Size:50gm</p>
                                <a class="btn btn-success" href="https://api.whatsapp.com/send?phone=9156965861&amp;"><i class="fa fa-whatsapp"></i> Order Now</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-6 mb-sm-3">
                        <div class="card">
                            <img src="img/th_1.avif" class="card-img-top " style="height: 200px;" alt="..." >
                            <div class="card-body text-center">
                                <h5 class="card-title">JSC NASIK RED ONION SEEDS N-53</h5>
                                <p>JSC Seeds</p>
                                <h6 class="card-subtitle mb-2 text-muted "><i class="fa fa-inr "></i>275/-<i class="fa fa-inr"></i><s>390</s></h6>
                                <p class="card-text ">
                                    Saved price <i class="fa fa-inr"></i>115</p>
                                    <p class="card-text ">
                                        Size:500GMS</p>
                                <a class="btn btn-success" href="https://api.whatsapp.com/send?phone=9156965861&amp;"><i class="fa fa-whatsapp"></i> Order Now</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-6 mb-sm-3">
                        <div class="card">
                            <img src="img/VNR_Krish_Cucumber.jpg" class="card-img-top " style="height: 200px;" alt="..." >
                            <div class="card-body text-center">
                                <h5 class="card-title">KRISH F1 CUCUMBER</h5>
                                <p>VNR</p>
                                <h6 class="card-subtitle mb-2 text-muted "><i class="fa fa-inr "></i>315/-<i class="fa fa-inr"></i><s>408</s></h6>
                                <p class="card-text ">
                                    Saved price <i class="fa fa-inr"></i>93</p>
                                    <p class="card-text ">
                                        Size:10GMS</p>
                                <a class="btn btn-success" href="https://api.whatsapp.com/send?phone=9156965861&amp;"><i class="fa fa-whatsapp"></i> Order Now</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div id="accessories" class="container tab-pane fade">
                <h3 class="text-center">Flower Seed</h3>
                <div class="row">
                <div class="col-md-3 col-sm-6 mb-sm-3">
                    <div class="card">
                        <img src="img/zendu.webp" class="card-img-top " style="height: 200px;" alt="..." >
                        <div class="card-body text-center">
                            <h5 class="card-title">NAMDHARI AFRICAN MARIGOLD DOUBLE ORANGE SEEDS</h5>
                            <p>Namdhari</p>
                            <h6 class="card-subtitle mb-2 text-muted "><i class="fa fa-inr "></i>250/-<i class="fa fa-inr"></i><s>360</s></h6>
                            <p class="card-text ">
                                Saved price <i class="fa fa-inr"></i>110</p>
                                <p class="card-text ">
                                    Size:10gm</p>
                            <a class="btn btn-success" href="https://api.whatsapp.com/send?phone=9156965861&amp;"><i class="fa fa-whatsapp"></i> Order Now</a>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 col-sm-6 mb-sm-3">
                    <div class="card">
                        <img src="img/b1.avif" class="card-img-top " style="height: 200px;" alt="..." >
                        <div class="card-body text-center">
                            <h5 class="card-title">SARPAN HYBRID CHRYSANTHEMUM (BIJALI WHITE) SEEDS</h5>
                            <p>Sarpan Hybrid Seeds Co</p>
                            <h6 class="card-subtitle mb-2 text-muted "><i class="fa fa-inr "></i>375/-<i class="fa fa-inr"></i><s>415</s></h6>
                            <p class="card-text ">
                                Saved price <i class="fa fa-inr"></i>40</p>
                                <p class="card-text ">
                                    Size:10gm</p>
                            <a class="btn btn-success" href="https://api.whatsapp.com/send?phone=9156965861&amp;"><i class="fa fa-whatsapp"></i> Order Now</a>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 col-sm-6 mb-sm-3">
                    <div class="card">
                        <img src="img/marrygold.webp" class="card-img-top " style="height: 200px;" alt="..." >
                        <div class="card-body text-center">
                            <h5 class="card-title">MAX YELLOW MARIGOLD</h5>
                            <p>ASHOKA</p>
                            <h6 class="card-subtitle mb-2 text-muted "><i class="fa fa-inr "></i>1335/-<i class="fa fa-inr"></i><s>4000</s></h6>
                            <p class="card-text ">
                                Saved price <i class="fa fa-inr"></i>2665</p>
                                <p class="card-text ">
                                    Size:1000seeds</p>
                            <a class="btn btn-success" href="https://api.whatsapp.com/send?phone=9156965861&amp;"><i class="fa fa-whatsapp"></i> Order Now</a>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 col-sm-6 mb-sm-3">
                    <div class="card">
                        <img src="img/iris.avif" class="card-img-top " style="height: 200px;" alt="..." >
                        <div class="card-body text-center">
                            <h5 class="card-title">IRIS CHRYSANTHEMUM CARINATUM FLOWER SEEDS</h5>
                            <p>Iris Hybrid</p>
                            <h6 class="card-subtitle mb-2 text-muted "><i class="fa fa-inr "></i>148/-<i class="fa fa-inr"></i><s>249</s></h6>
                            <p class="card-text ">
                                Saved price <i class="fa fa-inr"></i>101</p>
                                <p class="card-text ">
                                    Size:50seeds</p>
                            <a class="btn btn-success" href="https://api.whatsapp.com/send?phone=9156965861&amp;"><i class="fa fa-whatsapp"></i> Order Now</a>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 col-sm-6 mb-sm-3">
                    <div class="card">
                        <img src="img/gial1.avif" class="card-img-top " style="height: 200px;" alt="..." >
                        <div class="card-body text-center">
                            <h5 class="card-title">SARPAN HYBRID GAILARDIA - 2 MIX</h5>
                            <p>Sarpan Hybrid Seeds Co</p>
                            <h6 class="card-subtitle mb-2 text-muted "><i class="fa fa-inr "></i>350/-<i class="fa fa-inr"></i><s>375</s></h6>
                            <p class="card-text ">
                                Saved price <i class="fa fa-inr"></i>25</p>
                                <p class="card-text ">
                                    Size:10gm</p>
                            <a class="btn btn-success" href="https://api.whatsapp.com/send?phone=9156965861&amp;"><i class="fa fa-whatsapp"></i> Order Now</a>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 col-sm-6 mb-sm-3">
                    <div class="card">
                        <img src="img/pansy.webp" class="card-img-top " style="height: 200px;" alt="..." >
                        <div class="card-body text-center">
                            <h5 class="card-title">PANSY FLOWER</h5>
                            <p>Indo-American</p>
                            <h6 class="card-subtitle mb-2 text-muted "><i class="fa fa-inr "></i>544/-<i class="fa fa-inr"></i><s>750</s></h6>
                            <p class="card-text ">
                                Saved price <i class="fa fa-inr"></i>206</p>
                                <p class="card-text ">
                                    Size:250seeds</p>
                            <a class="btn btn-success" href="https://api.whatsapp.com/send?phone=9156965861&amp;"><i class="fa fa-whatsapp"></i> Order Now</a>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 col-sm-6 mb-sm-3">
                    <div class="card">
                        <img src="img/Sunflower.avif" class="card-img-top " style="height: 200px;" alt="..." >
                        <div class="card-body text-center">
                            <h5 class="card-title">URJA SUNFLOWER MICROGREENS</h5>
                            <p>URJA Seeds</p>
                            <h6 class="card-subtitle mb-2 text-muted "><i class="fa fa-inr "></i>300/-<i class="fa fa-inr"></i><s>499</s></h6>
                            <p class="card-text ">
                                Saved price <i class="fa fa-inr"></i>199</p>
                                <p class="card-text ">
                                    Size:100seeds</p>
                            <a class="btn btn-success" href="https://api.whatsapp.com/send?phone=9156965861&amp;"><i class="fa fa-whatsapp"></i> Order Now</a>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 col-sm-6 mb-sm-3">
                    <div class="card">
                        <img src="img/PORTULACA.jpg" class="card-img-top " style="height: 200px;" alt="..." >
                        <div class="card-body text-center">
                            <h5 class="card-title">PORTULACA</h5>
                            <p>ndo-American</p>
                            <h6 class="card-subtitle mb-2 text-muted "><i class="fa fa-inr "></i>539/-<i class="fa fa-inr"></i><s>550</s></h6>
                            <p class="card-text ">
                                Saved price <i class="fa fa-inr"></i>11</p>
                                <p class="card-text ">
                                    Size:500seeds</p>
                            <a class="btn btn-success" href="https://api.whatsapp.com/send?phone=9156965861&amp;"><i class="fa fa-whatsapp"></i> Order Now</a>
                        </div>
                    </div>
                </div>
            </div>
            </div>
            <div id="glass" class="container tab-pane fade">
                <h3 class="text-center">Fruit Seed</h3>
                <div class="row">
                    
                    <div class="col-md-3 col-sm-6 mb-sm-3">
                        <div class="card">
                            <img src="img/fruit.avif" class="card-img-top " style="height: 200px;" alt="..." >
                            <div class="card-body text-center">
                                <h5 class="card-title">IRIS HYBRID FRUIT SEEDS WATERMELON</h5>
                                <p>Iris Hybrid</p>
                                <h6 class="card-subtitle mb-2 text-muted "><i class="fa fa-inr "></i>136/-<i class="fa fa-inr"></i><s>299</s></h6>
                                <p class="card-text ">
                                    Saved price <i class="fa fa-inr"></i>163</p>
                                    <p class="card-text ">
                                        Size:15seeds</p>
                                <a class="btn btn-success" href="https://api.whatsapp.com/send?phone=9156965861&amp;"><i class="fa fa-whatsapp"></i> Order Now</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-6 mb-sm-3">
                        <div class="card">
                            <img src="img/green_9fb1112e-6d7f-444d-8c30-cbe5ae021622.jpg" class="card-img-top " style="height: 200px;" alt="..." >
                            <div class="card-body text-center">
                                <h5 class="card-title">GREEN LETTUCE</h5>
                                <p>ASHOKA</p>
                                <h6 class="card-subtitle mb-2 text-muted "><i class="fa fa-inr "></i>156/-<i class="fa fa-inr"></i><s>500</s></h6>
                                <p class="card-text ">
                                    Saved price <i class="fa fa-inr"></i>344</p>
                                    <p class="card-text ">
                                        Size:500seeds</p>
                                <a class="btn btn-success" href="https://api.whatsapp.com/send?phone=9156965861&amp;"><i class="fa fa-whatsapp"></i> Order Now</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-6 mb-sm-3">
                        <div class="card">
                            <img src="img/kundan.webp" class="card-img-top " style="height: 200px;" alt="..." >
                            <div class="card-body text-center">
                                <h5 class="card-title">KUNDAN F1 HYBRID MUSKMELON SEEDS</h5>
                                <p>Known-You</p>
                                <h6 class="card-subtitle mb-2 text-muted "><i class="fa fa-inr "></i>3100/-<i class="fa fa-inr"></i><s>3530</s></h6>
                                <p class="card-text ">
                                    Saved price <i class="fa fa-inr"></i>430</p>
                                    <p class="card-text ">
                                        Size:50gm</p>
                                <a class="btn btn-success" href="https://api.whatsapp.com/send?phone=9156965861&amp;"><i class="fa fa-whatsapp"></i> Order Now</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-6 mb-sm-3">
                        <div class="card">
                            <img src="img/musk.webp" class="card-img-top " style="height: 200px;" alt="..." >
                            <div class="card-body text-center">
                                <h5 class="card-title">SONA MUSK MELON</h5>
                                <p>Fito</p>
                                <h6 class="card-subtitle mb-2 text-muted "><i class="fa fa-inr "></i>1305/-<i class="fa fa-inr"></i><s>2530</s></h6>
                                <p class="card-text ">
                                    Saved price <i class="fa fa-inr"></i>1225</p>
                                    <p class="card-text ">
                                        Size:500seeds</p>
                                <a class="btn btn-success" href="https://api.whatsapp.com/send?phone=9156965861&amp;"><i class="fa fa-whatsapp"></i> Order Now</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-6 mb-sm-3">
                        <div class="card">
                            <img src="img/namwat.webp" class="card-img-top " style="height: 200px;" alt="..." >
                            <div class="card-body text-center">
                                <h5 class="card-title">NS 295 F1 HYBRID WATERMELON SEEDS, RIND TYPE LIGHT GREEN RIND WITH DARK GREEN STRIPES</h5>
                                <p>Namdhari</p>
                                <h6 class="card-subtitle mb-2 text-muted "><i class="fa fa-inr "></i>391/-<i class="fa fa-inr"></i><s>460</s></h6>
                                <p class="card-text ">
                                    Saved price <i class="fa fa-inr"></i>69</p>
                                    <p class="card-text ">
                                        Size:50gm</p>
                                <a class="btn btn-success" href="https://api.whatsapp.com/send?phone=9156965861&amp;"><i class="fa fa-whatsapp"></i> Order Now</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-6 mb-sm-3">
                        <div class="card">
                            <img src="img/ns901.webp" class="card-img-top " style="height: 200px;" alt="..." >
                            <div class="card-body text-center">
                                <h5 class="card-title">NS 910 MUSKMELON SEEDS</h5>
                                <p>Namdhari</p>
                                <h6 class="card-subtitle mb-2 text-muted "><i class="fa fa-inr "></i>878/-<i class="fa fa-inr"></i><s>1050</s></h6>
                                <p class="card-text ">
                                    Saved price <i class="fa fa-inr"></i>172</p>
                                    <p class="card-text ">
                                        Size:50gm</p>
                                <a class="btn btn-success" href="https://api.whatsapp.com/send?phone=9156965861&amp;"><i class="fa fa-whatsapp"></i> Order Now</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-6 mb-sm-3">
                        <div class="card">
                            <img src="img/pappya.webp" class="card-img-top " style="height: 200px;" alt="..." >
                            <div class="card-body text-center">
                                <h5 class="card-title">IRIS HYBRID PAPAYA SEEDS</h5>
                                <p>Iris Hybrid</p>
                                <h6 class="card-subtitle mb-2 text-muted "><i class="fa fa-inr "></i>196/-<i class="fa fa-inr"></i><s>449</s></h6>
                                <p class="card-text ">
                                    Saved price <i class="fa fa-inr"></i>253</p>
                                    <p class="card-text ">
                                        Size:10seeds</p>
                                <a class="btn btn-success" href="https://api.whatsapp.com/send?phone=9156965861&amp;"><i class="fa fa-whatsapp"></i> Order Now</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-6 mb-sm-3">
                        <div class="card">
                            <img src="img/waters.webp" class="card-img-top " style="height: 200px;" alt="..." >
                            <div class="card-body text-center">
                                <h5 class="card-title">APOORVA WATERMELON </h5>
                                <p>Seminis</p>
                                <h6 class="card-subtitle mb-2 text-muted "><i class="fa fa-inr "></i>355/-<i class="fa fa-inr"></i><s>440</s></h6>
                                <p class="card-text ">
                                    Saved price <i class="fa fa-inr"></i>85</p>
                                    <p class="card-text ">
                                        Size:50gm</p>
                                <a class="btn btn-success" href="https://api.whatsapp.com/send?phone=9156965861&amp;"><i class="fa fa-whatsapp"></i> Order Now</a>
                            </div>
                        </div>
                    </div>
                       
                </div>
            </div>
            
        </div>
    </div>
    <?php include('footer.php'); ?>