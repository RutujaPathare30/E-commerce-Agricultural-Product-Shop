<?php
 include_once("connection.php");
 if(isset($_POST['datasave'])){
    $form_name=$_POST['form_name'];
    $form_lastname=$_POST['form_lastname'];
    $form_EmailID=$_POST['form_EmailID'];
    $form_phone=$_POST['form_phone'];
    $form_address=$_POST['form_address'];
    $form_company=$_POST['form_company'];
    $form_website=$_POST['form_website'];
    $product=$_POST['product'];
    $seller=$_POST['seller'];
    
    $form_info=$_POST['form_info'];
    "<br>form_name = ".$form_name;
     "<br>form_lastname = ".$form_lastname;
     "<br>form_EmailID = ".$form_EmailID;
     "<br>form_phone = ".$form_phone;
     "<br>form_address = ".$form_address;
     "<br>form_company = ".$form_company;
     "<br>form_website = ".$form_website;
     "<br>product = ".$product;
     "<br>seller = ".$seller;
     "<br>form_info = ".$form_info;
    $inserttime =date('Y-m-d h:i:s a');
    $updatetime =date('Y-m-d h:i:s a');
    "<br>sqlquery = ".$sqlquery="insert into tblsell(form_name,form_lastname,form_EmailID,form_phone,form_address,form_company,form_website,product,seller,form_info,inserttime,updatetime) values('".$form_name."','".$form_lastname."','".$form_EmailID."','".$form_phone."','".$form_address."','".$form_company."','".$form_website."','".$product."','".$seller."','".$form_info."','".$inserttime."','".$updatetime."')";
    mysqli_query($con,$sqlquery);
    //mysqli_error($con);
    header('location:sell.php');
    //echo "<script> alert('contactus  save )
   }
 



 
 ?>