<?php include('navbar.php'); ?>
          
      
      <div id="carouselExampleCaptions" class="carousel slide" data-bs-ride="carousel">
        <div class="carousel-indicators">
            <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
            <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="1" aria-label="Slide 2"></button>
            <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="2" aria-label="Slide 3"></button>
            
        
        </div>
        <div class="carousel-inner">
            <div class="carousel-item active">
                <img src="img/Thumbnail seeds.jpg" class="d-block w-100" style="height: 450px;" alt="...">
                <div class="carousel-caption d-none d-md-block">
                    <h5></h5>
                    <p></p>
                </div>
            </div>
            <div class="carousel-item">
                <img src="img/Slide6-2.webp" class="d-block w-100" style="height: 450px;" alt="...">
                <div class="carousel-caption d-none d-md-block">
                    <h5></h5>
                    <p></p>
                </div>
            </div>
            <div class="carousel-item">
                <img src="img/Pesticides Slider KK-750x350.png" class="d-block w-100" style="height: 450px;" alt="...">
                <div class="carousel-caption d-none d-md-block">
                    <h5></h5>
                    <p></p>
                </div>
            </div>
           
        </div>
        <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="prev">
        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
        <span class="visually-hidden">Previous</span>
        </button>
        <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="next">
        <span class="carousel-control-next-icon" aria-hidden="true"></span>
        <span class="visually-hidden">Next</span>
        </button>
    </div>
    <div class="container-fluid">
  <div class="row mt-3">
    <h1 class="text-center">Categories</h1>
    <div class="col-md-3 col-sm-6">
      
        <img src="img/offer.webp" class="card-img-top mt-2 ms-5" style="border-radius: 50%; height: 150px; width: 200px;" alt="... ">
        
        <p  class="text-center">Offers</p>
        
       
    
    </div>
    <div class="col-md-3 col-sm-6">
      
      <img src="img/seed.webp" class="  mt-2 ms-5 " style="border-radius: 50%; height: 150px; width: 200px; text-align: center;" alt="... ">
      <p  class="text-center">Seed</p>
     
  
  </div>
  <div class="col-md-3 col-sm-6">
      
    <img src="img/chemical.webp" class="card-img-top mt-2 ms-5 " style="border-radius: 50%; height: 150px; width: 200px;" alt="... ">
    <p  class="text-center">Insecticides</p>
   

</div>
<div class="col-md-3 col-sm-6">
      
  <img src="img/organic.webp" class="card-img-top mt-2 ms-5" style="border-radius: 50%; height: 150px; width: 200px;" alt="... ">
  <p class="text-center">Organic Farming</p>
 

</div>

  </div>
  <div class="container-fluid">
  <div class="row mt-4">
    <h1 class="text-center">Exclusive</h1>
    <div class="col-md-3 col-sm-6">
      
        <img src="img/exclusive1.webp" class="card-img-top mt-2 " style=" height: 300px; width: 300px;" alt="... ">
        
        
        
       
    
    </div>
    <div class="col-md-3 col-sm-6">
      
      <img src="img/exclusive2.webp" class="card-img-top mt-2 " style=" height: 300px; width: 300px;" alt="... ">
      
      
      
     
  
  </div>
  <div class="col-md-3 col-sm-6">
      
    <img src="img/exclusive3.webp" class="card-img-top mt-2 " style=" height: 300px; width: 300px;" alt="... ">
    
    
    
   

</div>
<div class="col-md-3 col-sm-6">
      
  <img src="img/exclusive4.webp" class="card-img-top mt-2 " style=" height: 300px; width: 300px;" alt="... ">
  
  
  
 

</div>

  </div>
 </div>
  <div class="row mt-4">
    <h1 class="text-center">Brands</h1>
    <div class="col-md-2 col-sm-3">
      
        <img src="img/brand1.png" class="card-img-top mt-2 " style=" height: 150px; width: 150px;" alt="... ">
        
        
        
       
    
    </div>
    <div class="col-md-2 col-sm-3">
      
      <img src="img/brand2.png" class="card-img-top mt-2 " style=" height: 150px; width: 150px;" alt="... ">
      
      
      
     
  
  </div>
  <div class="col-md-2 col-sm-3">
      
    <img src="img/brand3.webp" class="card-img-top mt-2 " style=" height: 150px; width: 150px;" alt="... ">
    
    
    
   

</div>
<div class="col-md-2 col-sm-3">
      
  <img src="img/brand4.png" class="card-img-top mt-2 " style=" height: 150px; width: 150px;" alt="... ">
  
  
  
 

</div>
<div class="col-md-2 col-sm-3">
      
  <img src="img/brand5.png" class="card-img-top mt-2 " style=" height: 150px; width: 150px;" alt="... ">
  
  
  
 

</div>

<div class="col-md-2 col-sm-3">
      
  <img src="img/brand6.png" class="card-img-top mt-2 " style=" height: 150px; width: 150px;" alt="... ">
  
  
  
 

</div>
<div class="col-md-2 col-sm-3">
      
  <img src="img/brand7.png" class="card-img-top mt-2 " style=" height: 150px; width: 150px;" alt="... ">
  
  
  
 

</div>
<div class="col-md-2 col-sm-3">
      
  <img src="img/brand8.png" class="card-img-top mt-2 " style=" height: 150px; width: 150px;" alt="... ">
  
  
  
 

</div>
<div class="col-md-2 col-sm-3">
      
  <img src="img/brand9.png" class="card-img-top mt-2 " style=" height: 150px; width: 150px;" alt="... ">
  
  
  
 

</div>
<div class="col-md-2 col-sm-3">
      
  <img src="img/brand10.png" class="card-img-top mt-2 " style=" height: 150px; width: 150px;" alt="... ">
  
  
  
 

</div>
<div class="col-md-2 col-sm-3">
      
  <img src="img/brand11.png" class="card-img-top mt-2 " style=" height: 150px; width: 150px;" alt="... ">
  
  
  
 

</div>
<div class="col-md-2 col-sm-3">
      
  <img src="img/brand12.png" class="card-img-top mt-2 " style=" height: 150px; width: 150px;" alt="... ">
  
  
  
 

</div>

  </div>
    </div>
    <?php include('footer.php'); ?>