<?php include('navbar.php'); ?>
          
    
        <div class="row">
            <h3 class="text-center">Weekly Offer</h3>
            <div  class="col-md-6 col-sm-6">
                <div class="card">
                    <img src="img/offer1.jpg" class="m-4">

                </div>

            </div>
            <div  class="col-md-6 col-sm-6">
                <div class="card">
                    <img src="img/offer2.jpg" class="m-4">

                </div>

            </div>
            

        </div>
        <?php include('footer.php'); ?>