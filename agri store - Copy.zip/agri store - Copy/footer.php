<div class="container-fluid">
    <footer class="bg-dark mt-4">
      <div class="row">
        <div class="col-md-6 col-sm-12">
          <img src="img/agro.jpg" class="mt-3 ms-4" style="height: 75px; ">
          <p class="text-white ms-4 " style="text-justify:inter-word ; text-align: justify;">Agro is one of the largest and innovative Indian full-stack AgriTech platforms that is dedicated to revolutionizing the agricultural industry. The platform leverages technology to provide a wide range of solutions and services to farmers, helping them optimize their agricultural practices, increase productivity, and ultimately improve their livelihoods.</p>
  
            <p class="text-white ms-4" style="text-align: justify;">By integrating technology, data-driven insights, and a deep understanding of the agriculture sector, Agro aims to improve the overall agricultural ecosystem, increase farm yields, reduce input costs, and enhance the well-being of farmers across India. The platform plays a pivotal role in bridging the gap between technology and agriculture, ultimately contributing to the growth and sustainability of the agricultural sector.</p>
  
        </div>
        <div class="col-md-3 col-sm-12">
          
          <h4 class="text-white text-center mt-4 ">Connect</h4>
          <br>
          <i class=" fa fa-instagram fa-3x  ms-lg-4 text-danger "   ></i>
          
          <i class="fa fa-facebook fa-3x ms-lg-4 text-danger"></i>
          
          <i class="fa fa-youtube fa-3x ms-lg-4 text-danger "></i>
        </div>
        <div class="col-md-3 col-sm-12">
          <h4 class="text-center text-white mt-4">Contact Us</h4>
          <h5 class="text-white ">Missed Call To Order:</h5>
          <button class="bg-light text-danger " style="border-radius: 20px; ">-8668876041</button>
          <h5 class="text-white ">Whatsapp:</h5>
          <button class="bg-light text-danger " style="border-radius: 20px;">+9156965861</button>
           
        </div>
  
      </div>
      <br>
      <div class="row mt-4">
        <div class="col-md-12 col-sm-12">
          <p class="text-center h5 text-white"  ><i class="fa fa-globe"></i> Developed by Rutuja Pathare @2023-2024 .</p>
      <a href="admin/index.php" class="text-decoration-none "><p class="text-center text-white">All Rights are Reserved.</p><a>
      
        </div>
  
      </div>
  
  
    </footer>
    </div>
      
      
  </body>
  </php>