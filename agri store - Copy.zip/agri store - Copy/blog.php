<?php include('navbar.php'); ?>
    <div class="row">
        <h2 class="text-center">Blog</h2>
        <div class="col-md-6 col-sm-6">
            <div class="card">
                <img src="img/soyabeen.jpg" class="m-2" style="height: 300px; ;">
                <h4 class="ms-2 text-center">Soyabean:A Strategic Crop</h4>
                <div class="card-body">
                    <p style="text-align:justify">Increased soyabean production is necessary to meet an increasing domestic and global demand. Soyabean is one of the most common crops with multiple benefits to the farmer, the industry and the economy. However, current demand for soyabean in Kenya far outstrips supply, opening opportunities for farmers and the industry to plug in the disparities.

                        Soyabean crop is used as an affordable source of protein for livestock feeds. It is also used in making cooking oil, margarine, soya chunks, soap, milk, to name a few. It is one of the richest crops in terms of crude protein (ranging between 35-45 %) and contains 20 % oil. Improving soyabean production will surely increase its contribution to the Agriculture GDP.
                        
                        We can also imagine the amount of foreign exchange saving, the country will attain if the annual national requirement is produced locally.</p>

                </div>

            </div>

        </div>
        <div class="col-md-6 col-sm-6">
            <div class="card">
                <img src="img/organicfa.jpg" class="ms-lg-4 mt-2 " style="width: 500px; height: 300px; ">
                <h4 class="ms-2 text-center">Organic Farming</h4>
                <div class="card-body">
                    <p style="text-align:justify">Let’s talk about organic farming. This is an agricultural system that utilizes green manure, compost, biological pest control and crop rotation to produce crops, livestock and poultry. It’s a system that cultivates resources to conserve biodiversity and support ecological balance. Some of the primary aspects of organic farming are to augment the soil’s biological activity, enhance the fertility of the soil, and use green manure, cover crops, animal manure, and soil rotation to disturb the habitation of pests and diseases. Synthetic chemical fertilizers, antibiotics, herbicides or pesticides aren’t used in organic farming. The goal within organic farming is to manage agricultural production in the best natural way. Organic farming contributes added protection to the soil which in turn is crucial for exceptional productivity.</p>

                </div>

            </div>

        </div>

    </div>
    <?php include('footer.php'); ?>