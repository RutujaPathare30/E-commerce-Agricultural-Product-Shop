<?php include_once('adminnavbar.php'); ?>

      <main class="col-md-9 ml-sm-auto col-lg-10 px-md-4">
        <div
          class="row">
          <h1 class="h2"> Contact Us Data</h1>
        <div class="col-12">
          <table class="table table-borderd">
            <thead>
              <tr>
                <th>action</td>
                <th>id</th>
                <th>form_name</th>
                <th>form_lastname</th>
                <th>form_EmailID</th>
                <th>form_phone</th>
                <th>form_address</th>
                <th>form_message</th>
                <th>inserttime</th>
                <th>updatetime</th>
              </tr>
            </thead>
            <tbody>
                <?php 
                $sqlquery="select * from tblcontact";
                $res=mysqli_query($con,$sqlquery);
                $i=1;
                while($row = mysqli_fetch_assoc($res)){ 
                ?>
                    <tr>
                        <td>
                          <form action="" method="post">
                            <input type="hidden" name="id_<?php echo $row['id'];?>" id="id_<?php echo $row['id'];?>" value="<?php echo $row ['id']; ?>">
                            <button type="submit" name="delete_<?php echo $row['id']; ?>" class="btn btn-danger btn-sm"><i class="fa fa-trash"></i>Delete</button>
                          </form>
                          <?php 
                           if(isset($_POST['delete_'.$row['id']])){
                            $id=$_POST['id_'.$row['id']];
                            $delsql="delete from tblcontact where id='$id'";
                            $sss=mysqli_query($con,$delsql);
                            if($sss){
                              echo "<script> alert('partner Data Delete succesfully.')</script>";
                              echo "<script> window.location='admincontact.php';</script>";
                            }

                           }
                          ?>


                          
                        </td>
                        <td><?php echo $i++; ?></td>
                        <td><?php echo $row['form_name']; ?></td>
                        <td><?php echo $row['form_lastname']; ?></td>
                        <td><?php echo $row['form_EmailID']; ?></td>
                        <td><?php echo $row['form_phone']; ?></td>
                        <td><?php echo $row['form_address']; ?></td>
                       
                       
                        <td><?php echo $row['form_message']; ?></td>
                        <td><?php echo $row['inserttime']; ?></td>
                        <td><?php echo $row['updatetime']; ?></td>
                     </tr>
                     </tr>
              <?php  }
                ?>
            </tbody>
          </table>
          </div>
        </div>
      </main>
    </div>
  </div>
  <?php  include('adminfooter.php'); ?>
