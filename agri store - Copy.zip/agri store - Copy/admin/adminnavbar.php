<?php include('../connection.php'); ?>
<?php
 //echo $_SESSION['id'];
 if($_SESSION['id']==""){
  header('location:index.php');
 }
?>
<!doctype php>
<php lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="description" content="">
  <meta name="author" content="Mark Otto, Jacob Thornton, and Bootstrap contributors">
  <meta name="generator" content="Hugo 0.72.0">
  <title>Dashboard Template</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">  
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link href="https://cdn.datatables.net/1.13.7/css/jquery.dataTables.min.css" rel="stylesheet">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
  <script src="https://cdn.datatables.net/1.13.7/js/jquery.dataTables.min.js"></script>

  <style>
    .bd-placeholder-img {
      font-size: 1.125rem;
      text-anchor: middle;
      -webkit-user-select: none;
      -moz-user-select: none;
      -ms-user-select: none;
      user-select: none;
    }
    @media (min-width: 768px) {
      .bd-placeholder-img-lg {
        font-size: 3.5rem;
      }
    }
    body {
      font-size: .875rem;
    }
    .feather {
      width: 16px;
      height: 16px;
      vertical-align: text-bottom;
    }
    /* Sidebar*/
    .sidebar {
      /*position: fixed;*/
      top: 0;
      bottom: 0;
      left: 0;
      z-index: 100;
      /* Behind the navbar */
      padding: 48px 0 0;
      /* Height of navbar */
      box-shadow: inset -1px 0 0 rgba(0, 0, 0, .1);
    }
    @media (max-width: 767.98px) {
      .sidebar {
        top: 5rem;
      }
    }
    .sidebar-sticky {
      position: relative;
      top: 0;
      height: calc(100vh - 48px);
      padding-top: .5rem;
      overflow-x: hidden;
      overflow-y: auto;
      /* Scrollable contents if viewport is shorter than content. */
    }
    .sidebar .nav-link {
      font-weight: 500;
      color: #333;
    }
    .sidebar .nav-link .feather {
      margin-right: 4px;
      color: #727272;
    }
    .sidebar .nav-link.active {
      color: #007bff;
    }
    .sidebar .nav-link:hover .feather,
    .sidebar .nav-link.active .feather {
      color: inherit;
    }
    .sidebar-heading {
      font-size: .75rem;
      text-transform: uppercase;
    }
    /Navbar/
    .navbar-brand {
      padding-top: .75rem;
      padding-bottom: .75rem;
      font-size: 1rem;
      background-color: rgba(0, 0, 0, .25);
      box-shadow: inset -1px 0 0 rgba(0, 0, 0, .25);
    }
    .navbar .navbar-toggler {
      top: .25rem;
      right: 1rem;
    }
    .navbar .form-control {
      padding: .75rem 1rem;
      border-width: 0;
      border-radius: 0;
    }
    .form-control-dark {
      color: #fff;
      background-color: rgba(255, 255, 255, .1);
      border-color: rgba(255, 255, 255, .1);
    }
    .form-control-dark:focus {
      border-color: transparent;
      box-shadow: 0 0 0 3px rgba(255, 255, 255, .25);
    }
  </style>
</head>
<body>
  <nav class="navbar navbar-dark sticky-top bg-dark flex-md-nowrap p-0 shadow">
    <a class="navbar-brand col-md-3 col-lg-2 mr-0 px-3" href="#">Agro</a>
    <button class="navbar-toggler position-absolute d-md-none collapsed" type="button" data-toggle="collapse"
      data-target="#sidebarMenu" aria-controls="sidebarMenu" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
     <ul class="navbar-nav px-3">
      <li class="nav-item text-nowrap">
        <a class="nav-link" href="index.php">Sign out</a>
      </li>
    </ul>
  </nav>
  <div class="container-fluid">
    <div class="row">
      <nav id="sidebarMenu" class="col-md-3 col-lg-2 d-md-block bg-light sidebar collapse">
        <div class="position-sticky pt-3">
          <ul class="nav flex-column">
            <li class="nav-item">
              <a class="nav-link" href="#">
                <span data-feather="home"></span>
                <i class="fa fa-user"></i> <?php echo $_SESSION['username']; ?>
              </a>
            </li>

            

            <li class="nav-item">
              <a class="nav-link active" aria-current="page" href="dashboard.php">
                <span data-feather="home"></span>
                Dashboard
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="adminchemical.php">
                <span data-feather="file"></span>
                Chemical Pesticides
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="adminorganic.php">
                <span data-feather="file"></span>
                Organic Pesticides
              </a>
            </li>
            
            <li class="nav-item">
              <a class="nav-link" href="adminseed.php">
                <span data-feather="file"></span>
                Seed
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="adminholti.php">
                <span data-feather="file"></span>
                holticulture seed
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="admincontact.php">
                <span data-feather="file"></span>
                Contact
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="adminbulk.php">
                <span data-feather="file"></span>
                Bulk Inquiries
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="adminsell.php">
                <span data-feather="file"></span>
                Sell on Agro
              </a>
            </li>
           
          </ul>
        </div>
      </nav>
      