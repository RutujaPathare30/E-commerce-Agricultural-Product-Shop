<!DOCTYPE php>
<php lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js" integrity="sha384-7+zCNj/IqJ95wo16oMtfsKbZ9ccEh31eOz1HGyDuCQ6wgnyJNSYdrPa03rtR1zdB" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js" integrity="sha384-QJHtvGhmr9XOIpI6YVutG+2QOK9T+ZnN4kzFN1RtK3zEFEIsxhlmWl5/YESvpZ13" crossorigin="anonymous"></script>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>

    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@500&display=swap" rel="stylesheet">
    <script src="js/bootstrap.bundle.min.js"></script>
    <style>
        body{background-image:url("https://m.media-amazon.com/images/W/MEDIAX_792452-T2/images/I/71+17bVYHxL._AC_UF1000,1000_QL80_.jpg");
            background-repeat:no-repeat;
            background-size:cover;
        }

    </style>

</head>
<body >
<?php 
        include_once('../connection.php');
        if(isset($_POST['login'])){
            $username=$_POST['username'];
            $password=$_POST['password'];
            $sqlquery="select * from dimuser where username='".$username."' and password='".$password."'";
            $res=mysqli_query($con,$sqlquery);
            if(mysqli_num_rows($res)>0){
                $row=mysqli_fetch_assoc($res);
                $_SESSION['id']=$row['id'];
                $_SESSION['username']=$row['username'];
                $otp=rand(111111,999999);
                $update="update dimuser set otp='".$otp."' where id='".$row['id']."'";
                mysqli_query($con,$update);
                $_SESSION['otp']=$otp;
                echo "<script> alert('Login Successfully.');</script>";
                echo "<script> window.location='otp.php';</script>";
                
            }else{
                echo "<script> alert('Your Username & Password Not Match. Please try Again.');</script>";
                echo "<script> window.location='index.php';</script>";
            }
        }
    ?>
    
    <div class="container bg-white mt-5 mx-auto p-3" style="width: 500px;border-radius: 50px;">
        <form action="" method="post">
            <div class="row">
                <h1 class="text-center">Admin Login</h1>
                <div class="col-12 p-5 ">
                    <div class="row mb-3">
                        <div class="col-12">
                            <div class="input-group">
                                <label for="" class="input-group-text"><i class="fa fa-user"></i></label>
                                <input type="text" name="username" class="form-control" id="username" placeholder="Enter Username">
                            </div>
                        </div>
                    </div>
                    <div class="row mb-3">
                        <div class="col-12">
                            <div class="input-group">
                                <label for="" class="input-group-text"><i class="fa fa-key"></i></label>
                                <input type="Password" name="password" class="form-control" id="password" placeholder="Enter Password">
                            </div>
                        </div>
                    </div>
                    <div class="row mb-3">
                        <div class="col-12">
                            <div class="form-check">
                                <input type="radio" class="form-check-input" id="check1" name="option1" value="something" onclick="showpassword()">
                                <label class="form-check-label" for="check1">Show Password</label>
                            </div>
                        </div>
                    </div>
                    <div class="row mb-3">
                        <div class="col-12 text-center">
                            <button type="submit" class="btn btn-primary" name="login">Login</button>
                            <button type="reset" class="btn btn-warning">Reset</button>
                        </div>
                    </div>
                </div>
            </div>
        </form>
    </div>
    <script>
        function showpassword() {
            var x = document.getElementById("password");
            if (x.type === "password") {
                x.type = "text";
            } else {
                x.type = "password";
            }
        }
    </script>
</body>
</php>
