<?php include('adminnavbar.php'); ?>

<main class="col-md-9 ml-sm-auto col-lg-10 px-md-4">
    <div class="container-fluid">
        <h1 class="h2">Dashboard</h1>
        <div class="row">
            <div class="col-xl-3 col-md-6 mb-4">
                <a href="adminchemical.php" class="text-decoration-none">
                    <div class="card border-left-primary shadow h-100 py-2">
                        <div class="card-body">
                            <div class="row no-gutters align-items-center">
                                <div class="col mr-2">
                                    <div class="h5  font-weight-bold  text-uppercase mb-1"style=" color: rgb(223, 119, 29);">
                                        Chemical Pesticides
                                    </div>
                                    <div class="text-xs mb-0 font-weight-bold "style=" color: rgb(223, 119, 29);">
                                        View Details
                                    </div>
                                </div>
                                
                            </div>
                        </div>
                    </div>
                </a>
            </div>
            <div class="col-xl-3 col-md-6 mb-4">
                <a href="adminorganic.php" class="text-decoration-none">
                    <div class="card border-left-primary shadow h-100 py-2">
                        <div class="card-body">
                            <div class="row no-gutters align-items-center">
                                <div class="col mr-2">
                                    <div class="h5  font-weight-bold  text-uppercase mb-1"style=" color: rgb(223, 119, 29);">
                                        Organic Pesticides
                                    </div>
                                    <div class="text-xs mb-0 font-weight-bold "style=" color: rgb(223, 119, 29);">
                                        View Details
                                    </div>
                                </div>
                                
                            </div>
                        </div>
                    </div>
                </a>
            </div>
            <div class="col-xl-3 col-md-6 mb-4">
                <a href="adminseed.php" class="text-decoration-none">
                    <div class="card border-left-primary shadow h-100 py-2">
                        <div class="card-body">
                            <div class="row no-gutters align-items-center">
                                <div class="col mr-2">
                                    <div class="h5  font-weight-bold  text-uppercase mb-1"style=" color: rgb(223, 119, 29);">
                                    Seed
                                    </div>
                                    <div class="text-xs mb-0 font-weight-bold "style=" color: rgb(223, 119, 29);">
                                        View Details
                                    </div>
                                </div>
                                
                            </div>
                        </div>
                    </div>
                </a>
            </div>
            <div class="col-xl-3 col-md-6 mb-4">
                <a href="adminholti.php" class="text-decoration-none">
                    <div class="card border-left-primary shadow h-100 py-2">
                        <div class="card-body">
                            <div class="row no-gutters align-items-center">
                                <div class="col mr-2">
                                    <div class="h5  font-weight-bold  text-uppercase mb-1"style=" color: rgb(223, 119, 29);">
                                    holticulture Seed
                                    </div>
                                    <div class="text-xs mb-0 font-weight-bold "style=" color: rgb(223, 119, 29);">
                                        View Details
                                    </div>
                                </div>
                               
                            </div>
                        </div>
                    </div>
                </a>
            </div>
            <div class="col-xl-3 col-md-6 mb-4">
                <a href="admincontact.php" class="text-decoration-none">
                    <div class="card border-left-primary shadow h-100 py-2">
                        <div class="card-body">
                            <div class="row no-gutters align-items-center">
                                <div class="col mr-2">
                                    <div class="h5  font-weight-bold  text-uppercase mb-1"style=" color: rgb(223, 119, 29);">
                                    Contact
                                    </div>
                                    <div class="text-xs mb-0 font-weight-bold "style=" color: rgb(223, 119, 29);">
                                        View Details
                                    </div>
                                </div>
                                
                            </div>
                        </div>
                    </div>
                </a>
            </div>
            <div class="col-xl-3 col-md-6 mb-4">
                <a href="adminbulk.php" class="text-decoration-none">
                    <div class="card border-left-primary shadow h-100 py-2">
                        <div class="card-body">
                            <div class="row no-gutters align-items-center">
                                <div class="col mr-2">
                                    <div class="h5  font-weight-bold  text-uppercase mb-1"style=" color: rgb(223, 119, 29);">
                                    Bulk Inquiries
                                    </div>
                                    <div class="text-xs mb-0 font-weight-bold "style=" color: rgb(223, 119, 29);">
                                        View Details
                                    </div>
                                </div>
                                
                            </div>
                        </div>
                    </div>
                </a>
            </div>
            <div class="col-xl-3 col-md-6 mb-4">
                <a href="adminsell.php" class="text-decoration-none">
                    <div class="card border-left-primary shadow h-100 py-2">
                        <div class="card-body">
                            <div class="row no-gutters align-items-center">
                                <div class="col mr-2">
                                    <div class="h5  font-weight-bold  text-uppercase mb-1"style=" color: rgb(223, 119, 29);">
                                    Sell on Agro
                                    </div>
                                    <div class="text-xs mb-0 font-weight-bold text-gray-800"style=" color: rgb(223, 119, 29);">
                                        View Details
                                    </div>
                                </div>
                                
                            </div>
                        </div>
                    </div>
                </a>
            </div>
            
            <div class="col-xl-3 col-md-6 mb-4">
                <a href="index.php" class="text-decoration-none">
                    <div class="card border-left-primary shadow h-100 py-2">
                        <div class="card-body">
                            <div class="row no-gutters align-items-center">
                                <div class="col mr-2">
                                    <div class="h5  font-weight-bold text-uppercase mb-1"style=" color: rgb(223, 119, 29);">
                                    Logout
                                    </div>
                                    <div class="text-xs mb-0 font-weight-bold "style=" color: rgb(223, 119, 29);">
                                        View Details
                                    </div>
                                </div>
                                <div class="col-auto">
                                    <i class="fa fa-sign-out fa-2x "style=" color: rgb(223, 119, 29);"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </a>
            </div>
        </div>
    </div>
</main>

  <?php include('adminfooter.php'); ?>