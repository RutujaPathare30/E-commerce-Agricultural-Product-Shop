<!DOCTYPE php>
<php lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>otp verification</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js" integrity="sha384-7+zCNj/IqJ95wo16oMtfsKbZ9ccEh31eOz1HGyDuCQ6wgnyJNSYdrPa03rtR1zdB" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js" integrity="sha384-QJHtvGhmr9XOIpI6YVutG+2QOK9T+ZnN4kzFN1RtK3zEFEIsxhlmWl5/YESvpZ13" crossorigin="anonymous"></script>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>

    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@500&display=swap" rel="stylesheet">
    <script src="js/bootstrap.bundle.min.js"></script>
    <style>
        body{background-image:url("https://m.media-amazon.com/images/W/MEDIAX_792452-T2/images/I/71+17bVYHxL._AC_UF1000,1000_QL80_.jpg");
            background-repeat:no-repeat;
            background-size:cover;
        }

    </style>

</head>
<body >
    <?php
     include_once('../connection.php');
     if(isset($_POST['checkotp'])){
        
        $otp=$_SESSION['otp'];
        $sqlquery="select * from dimuser where otp='".$otp."' and id='".$_SESSION['id']."'";
        $res=mysqli_query($con,$sqlquery);
        if(mysqli_num_rows($res)>0){
            $row=mysqli_fetch_assoc($res);
            echo "<script> alert('otp verify Sucessfully. ' );</script>";
            echo "<script> window.location='dashboard.php';</script>";

        }else{
            echo "<script> alert('your entered otp not matched. ' );</script>";
            echo "<script> window.location='otp.php';</script>";
        }
     }

     ?>
    

    <div class="container bg-white " style="height:370px;width:450px;border-radius:65px;margin-top:100px">
        <div class="row">
            <h1 class="text-center p-2">otp verification</h1>
           <h5 class="text-center">OTP send on +9156965861</h5>
           <h5 class="text-center">OTP : <?php echo $_SESSION['otp']; ?></h5>
        


            
            <hr>
        
            <div class="col-md-12">
                <form action="" method="post">
                    
                       
                        <div class="form-float input-group mb-3 mt-3">
                          <span for="password" class="input-group-text slash" > <i class="fa fa-key"></i></span>
                            <input type="password" class="form-control" id="otp" placeholder="Enter otp" name="password">
                            
                            <br>
                            <br>
                            

                        </div>
                        <input type="checkbox" onclick="myFunction()">  Show otp

                        <div class="form-check mb-3">
                            <label class="form-check-label">
                            <input class="form-check-input" type="checkbox" name="remember"> Remember me
                            </label>
                        </div>
                        <center>
                        <button type="submit" class="btn btn-primary mb-3 " name="checkotp">verify otp</button>
                        <button type="reset" class="btn btn-warning mb-3 ">Reset</button>
                        </center>
                        
                </form>
                <br>
            </div>
      </div>
    </div>
    <script>
        function myFunction() {
          var x = document.getElementById("otp");
          if (x.type === "password") {
            x.type = "text";
          } else {
            x.type = "password";
          }
        }
    </script>    

    
</body>
</php>