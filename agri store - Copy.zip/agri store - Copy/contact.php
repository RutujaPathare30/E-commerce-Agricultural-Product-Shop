<?php include('navbar.php'); ?>
          
<div class="container-fluid mt-lg-4  " style="align-content: centers;">
    <h2 class="text-center">Contact Us </h2>
    <p class="text-black-50 text-center">Contact our experts for more details and start earning.</p>
    <div class="col-md-12 col-sm-12  rounded-3  " >
      <h3 class="text-center">Get in Touch</h3>
      <form method="post" action="contactsave.php"  style="margin-left: 350px; margin-right: 300px;" onsubmit="return validation();">
          <div class="messages"></div>
          <div class="controls">
              <div class="row">
                  <div class="col-md-6">
                      <div class="form-group mb-2">
                          <label for="form_name">Firstname <span class="text-danger">*</span></label>
                          <input id="form_name" type="text" name="form_name" class="form-control" placeholder="Firstname" required="">
                      </div>
                  </div>
                  <div class="col-md-6">
                      <div class="form-group mb-2">
                          <label for="form_lastname">Last name<span class="text-danger">*</span></label>
                          <input id="form_lastname" type="text" name="form_lastname" class="form-control" placeholder="Lastname" required="">
                      </div>
                  </div>
              </div>
              <div class="row ">
                  <div class="col-md-6">
                      <div class="form-group mb-2">
                          <label for="form_EmailID">Email<span class="text-danger">*</span></label>
                          <input id="form_EmailID" type="email" name="form_EmailID" class="form-control" placeholder="email" required="">
                      </div>
                  </div>
                  <div class="col-md-6">
                      <div class="form-group mb-2">
                          <label for="form_phone">Phone</label>
                          <input id="form_phone" type="tel" name="form_phone" class="form-control" placeholder="phone">
                      </div>
                  </div>
                  
              </div>
              <div class="row">
                <div class="col-md-12">
                    <div class="form-group mb-2">
                        <label for="form_address">Address<span class="text-danger">*</span></label>
                        <textarea id="form_address" name="form_address" class="form-control" placeholder="address" rows="4" required="required"></textarea>
                    </div>
                </div>
              <div class="row">
                  <div class="col-md-12">
                      <div class="form-group mb-2">
                          <label for="form_message">Your message<span class="text-danger">*</span></label>
                          <textarea id="form_message" name="form_message" class="form-control" placeholder="message" rows="4" required="required"></textarea>
                      </div>
                  </div>
                  <div class="col-md-12 mt-2">
                      <input type="submit" class="btn btn-danger btn-send " name="datasave"  value="submit">
                  </div>
              </div>
          </div>
</div>
      </form>


  </div>

  </div>
  <script>
        function validation() {
            var form_name = document.getElementById('form_name').value;
            var form_lastname= document.getElementById('form_lastname').value;
            var form_EmailID = document.getElementById('form_EmailID').value;
            var form_phone = document.getElementById('form_phone').value;
            var form_address = document.getElementById('form_address').value;
            var form_message= document.getElementById('form_message').value;
            if (form_name.trim() == '') {
                alert('Please Enter Your Name');
                document.getElementById('form_name').value = "";
                document.getElementById('form_name').focus();
                return false;
            }
            if (form_lastname.trim() == '') {
                alert('Please Enter Your Surname');
                document.getElementById('form_lastname').value = "";
                document.getElementById('form_lastname').focus();
                return false;
            }
            if (form_EmailID.trim() == '') {
                alert('Please Enter Your Email Id');
                document.getElementById('form_EmailID').value = "";
                document.getElementById('form_EmailID').focus();
                return false;
            }
            if (form_phone.trim() == '') {
                alert('Please Enter Your Mobile No');
                document.getElementById('form_phone').value = "";
                document.getElementById('form_phone').focus();
                return false;
            }
            if (form_address.trim() == '') {
                alert('Please Enter address ');
                document.getElementById('form_address').value = "";
                document.getElementById('form_address').focus();
                return false;
            } 
            if (form_message.trim() == '') {
                alert('Please Enter Your Message');
                document.getElementById('form_message').value = "";
                document.getElementById('form_message').focus();
                return false;
            }
            return true;
        }
    </script>
  <?php include('footer.php'); ?>