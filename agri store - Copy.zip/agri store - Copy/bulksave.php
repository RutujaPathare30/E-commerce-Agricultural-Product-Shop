<?php
 include_once("connection.php");
 if(isset($_POST['datasave'])){
    $form_name=$_POST['form_name'];
    $form_lastname=$_POST['form_lastname'];
    $form_EmailID=$_POST['form_EmailID'];
    $form_phone=$_POST['form_phone'];
    $form_address=$_POST['form_address'];
    $user=$_POST['user'];
    $form_product=$_POST['form_product'];
    $form_info=$_POST['form_info'];
    "<br>form_name = ".$form_name;
     "<br>form_lastname = ".$form_lastname;
     "<br>form_EmailID = ".$form_EmailID;
     "<br>form_phone = ".$form_phone;
     "<br>form_address = ".$form_address;
     "<br>user = ".$user;
     "<br>form_product = ".$form_product;
    
     "<br>form_info = ".$form_info;
    $inserttime =date('Y-m-d h:i:s a');
    $updatetime =date('Y-m-d h:i:s a');
    "<br>sqlquery = ".$sqlquery="insert into tblbulk(form_name,form_lastname,form_EmailID,form_phone,form_address,user,form_product,form_info,inserttime,updatetime) values('".$form_name."','".$form_lastname."','".$form_EmailID."','".$form_phone."','".$form_address."','".$user."','".$form_product."','".$form_info."','".$inserttime."','".$updatetime."')";
    mysqli_query($con,$sqlquery);
    //mysqli_error($con);
    header('location:bulk.php');
    //echo "<script> alert('contactus  save )
   }
 



 
 ?>