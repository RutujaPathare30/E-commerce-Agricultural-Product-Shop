<?php include('navbar.php'); ?>
          
    <div class="container mt-3">
        <h1 class="text-center">Organic Pesticides</h1>
        <!-- Nav tabs -->
        
        <div class="tab-content">
        
                <div class="row">
                    
                    <div class="col-md-3 col-sm-6 mb-sm-3">
                        <div class="card">
                            <img src="img/econ.webp" class="card-img-top " style="height: 230px;" alt="..." >
                            <div class="card-body text-center">
                                <h5 class="card-title">ECONEEM PLUS - AZADIRACHTIN 10000 PPM - BIOPESTICIDE</h5>
                                <p>MARGO</p>
                                <h6 class="card-subtitle mb-2 text-muted "><i class="fa fa-inr"></i>435/-<i class="fa fa-inr"></i><s>579</s></h6>
                                <p class="card-text ">
                                    Saved price<i class="fa fa-inr"></i>144</p>
                                    <p class="card-text ">
                                        Size:100ml</p>
                                <a class="btn btn-success" href="https://api.whatsapp.com/send?phone=9156965861&amp;"><i class="fa fa-whatsapp"></i> Order Now</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-6 mb-sm-3">
                        <div class="card">
                            <img src="img/raj.jpg" class="card-img-top " style="height: 230px;" alt="..." >
                            <div class="card-body text-center">
                                <h5 class="card-title">Thrips Raze Bio Pesticide </h5>
                                <p>Kay bee</p>
                                <h6 class="card-subtitle mb-2 text-muted "><i class="fa fa-inr "></i>304/-<i class="fa fa-inr"></i><s>324</s></h6>
                                <p class="card-text ">
                                    Saved price <i class="fa fa-inr"></i>20</p>
                                    <p class="card-text ">
                                        Size:100ml</p>
                                <a class="btn btn-success" href="https://api.whatsapp.com/send?phone=9156965861&amp;"><i class="fa fa-whatsapp"></i> Order Now</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-6 mb-sm-3">
                        <div class="card">
                            <img src="img/solder.webp" class="card-img-top " style="height: 200px;" alt="..." >
                            <div class="card-body text-center">
                                <h5 class="card-title">SOLDIER (EPN)</h5>
                                <p>Multiplex</p>
                                <h6 class="card-subtitle mb-2 text-muted "><i class="fa fa-inr "></i>678/-<i class="fa fa-inr"></i><s>960</s></h6>
                                <p class="card-text ">
                                    Saved price <i class="fa fa-inr"></i>282</p>
                                    <p class="card-text ">
                                        Size :1kg</p>
                                <a class="btn btn-success" href="https://api.whatsapp.com/send?phone=9156965861&amp;"><i class="fa fa-whatsapp"></i> Order Now</a>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-md-3 col-sm-6 mb-sm-3">
                        <div class="card">
                            <img src="img/ruy.webp" class="card-img-top " style="height: 200px;" alt="..." >
                            <div class="card-body text-center">
                                <h5 class="card-title">ECODERMA TRICHODERMA VIRIDE BIOFUNGICIDE</h5>
                                <p>MARGO</p>
                                <h6 class="card-subtitle mb-2 text-muted "><i class="fa fa-inr "></i>230/-<i class="fa fa-inr"></i><s>375</s></h6>
                                <p class="card-text ">
                                    Saved price <i class="fa fa-inr"></i>145</p>
                                    <p class="card-text ">
                                        Size:1kg</p>
                                <a class="btn btn-success" href="https://api.whatsapp.com/send?phone=9156965861&amp;"><i class="fa fa-whatsapp"></i> Order Now</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-6 mb-sm-3">
                        <div class="card">
                            <img src="img/p3.avif" class="card-img-top " style="height: 200px;" alt="..." >
                            <div class="card-body text-center">
                                <h5 class="card-title">PIONEER AGRO TRICHODERMA VIRIDE (BIO FUNGICIDE)</h5>
                                <p>Pioneer Agro</p>
                                <h6 class="card-subtitle mb-2 text-muted "><i class="fa fa-inr "></i>535/-<i class="fa fa-inr"></i><s>716</s></h6>
                                <p class="card-text ">
                                    Saved price <i class="fa fa-inr"></i>181</p>
                                    <p class="card-text ">
                                        Size:1kg</p>
                                <a class="btn btn-success" href="https://api.whatsapp.com/send?phone=9156965861&amp;"><i class="fa fa-whatsapp"></i> Order Now</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-6 mb-sm-3">
                        <div class="card">
                            <img src="img/aal.jpg" class="card-img-top " style="height: 200px;" alt="..." >
                            <div class="card-body text-center">
                                <h5 class="card-title">AMRUTH ALMONAS LIQUID (BIO FUNGICIDE)</h5>
                                <p>Amruth Organic</p>
                                <h6 class="card-subtitle mb-2 text-muted "><i class="fa fa-inr "></i>737/-<i class="fa fa-inr"></i><s>810</s></h6>
                                <p class="card-text ">
                                    Saved price <i class="fa fa-inr"></i>73</p>
                                    <p class="card-text ">
                                        Size:1L</p>
                                <a class="btn btn-success" href="https://api.whatsapp.com/send?phone=9156965861&amp;"><i class="fa fa-whatsapp"></i> Order Now</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-6 mb-sm-3">
                        <div class="card">
                            <img src="img/virus.webp" class="card-img-top " style="height: 200px;" alt="..." >
                            <div class="card-body text-center">
                                <h5 class="card-title">NO VIRUS (BIO VIRICIDE)</h5>
                                <p>Geolife</p>
                                <h6 class="card-subtitle mb-2 text-muted "><i class="fa fa-inr "></i>279/-<i class="fa fa-inr"></i><s>330</s></h6>
                                <p class="card-text ">
                                    Saved price <i class="fa fa-inr"></i>51</p>
                                    <p class="card-text ">
                                        Size:250ml</p>
                                <a class="btn btn-success" href="https://api.whatsapp.com/send?phone=9156965861&amp;"><i class="fa fa-whatsapp"></i> Order Now</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-6 mb-sm-3">
                        <div class="card">
                            <img src="img/vbind.webp" class="card-img-top " style="height: 200px;" alt="..." >
                            <div class="card-body text-center">
                                <h5 class="card-title">V-BIND BIO VIRICIDE</h5>
                                <p>Vanproz</p>
                                <h6 class="card-subtitle mb-2 text-muted "><i class="fa fa-inr "></i>320/-<i class="fa fa-inr"></i><s>450</s></h6>
                                <p class="card-text ">
                                    Saved price <i class="fa fa-inr"></i>130</p>
                                    <p class="card-text ">
                                        Size:100ML</p>
                                <a class="btn btn-success" href="https://api.whatsapp.com/send?phone=9156965861&amp;"><i class="fa fa-whatsapp"></i> Order Now</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-6 mb-sm-3">
                        <div class="card">
                            <img src="img/katara.webp" class="card-img-top " style="height: 200px;" alt="..." >
                            <div class="card-body text-center">
                                <h5 class="card-title">KATRA VIRUS-G VIRICIDE + MITICIDE (COMBO)</h5>
                                <p>KATRA FERTILIZERS AND CHEMICALS PVT LTD</p>
                                <h6 class="card-subtitle mb-2 text-muted "><i class="fa fa-inr "></i>1395/-<i class="fa fa-inr"></i><s>1620</s></h6>
                                <p class="card-text ">
                                    Saved price <i class="fa fa-inr"></i>225</p>
                                    <p class="card-text ">
                                        Size:250ml</p>
                                <a class="btn btn-success" href="https://api.whatsapp.com/send?phone=9156965861&amp;"><i class="fa fa-whatsapp"></i> Order Now</a>
                            </div>
                        </div>
                    </div>
                </div>
         </div>
            
    </div>
    <?php include('footer.php'); ?>