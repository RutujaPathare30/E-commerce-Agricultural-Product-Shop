<?php include('navbar.php'); ?>
          
          <div class="container-fluid mt-lg-4  " style="align-content: centers;">
    
    <div class="col-md-12 col-sm-12  rounded-3  " >
      <h3 class="text-center">Sell On Agro</h3>
      <hr style="margin-left: 300px; margin-right: 300px;">
      <form method="post" action="sellsave.php"  style="margin-left: 350px; margin-right: 320px;">
          <div class="messages"></div>
          <div class="controls">
              <div class="row">
                  <div class="col-md-6">
                      <div class="form-group mb-2">
                          <label for="form_name">Firstname <span class="text-danger">*</span></label>
                          <input id="form_name" type="text" name="form_name" class="form-control" placeholder="Firstname" required="">
                      </div>
                  </div>
                  <div class="col-md-6">
                      <div class="form-group mb-2">
                          <label for="form_lastname">Last name<span class="text-danger">*</span></label>
                          <input id="form_lastname" type="text" name="form_lastname" class="form-control" placeholder="Lastname" required="">
                      </div>
                  </div>
              </div>
              <div class="row ">
                  <div class="col-md-6">
                      <div class="form-group mb-2">
                          <label for="form_EmailID">Email<span class="text-danger">*</span></label>
                          <input id="form_EmailID" type="form_EmailID" name="form_EmailID" class="form-control" placeholder="email" required="">
                      </div>
                  </div>
                  <div class="col-md-6">
                      <div class="form-group mb-2">
                          <label for="form_phone">Phone</label>
                          <input id="form_phone" type="tel" name="form_phone" class="form-control" placeholder="phone">
                      </div>
                  </div>
                  
              </div>
              <div class="row">
                <div class="col-md-12">
                    <div class="form-group mb-2">
                        <label for="form_address">Address<span class="text-danger">*</span></label>
                        <input id="form_address" name="form_address" class="form-control" placeholder="address" rows="4" required="required">
                    </div>
                </div>
              </div>
              <div class="row">
                <div class="col-md-12">
                    <div class="form-group mb-2">
                        <label for="form_address">Company/Brand Name<span class="text-danger">*</span></label>
                        <input id="form_company" name="form_company" class="form-control" placeholder="company/Brand name" rows="4" required="required">
                    </div>
                </div>
              </div>
              <div class="row">
                <div class="col-md-12">
                    <div class="form-group mb-2">
                        <label for="form_address">Website<span class="text-danger">*</span></label>
                        <input id="form_website" name="form_website" class="form-control"  rows="4" required="required">
                    </div>
                </div>
              </div>
              
              <div class="row">
                
                <div class="col-md-12">
                            <div class="form-group mb-2">
                                <label for="seller">Category of Product<span class="text-danger" reuired="required">*</span></label>
                                <select id="product" name="product">
                                    <option value="Nutrients">Nutrients</option>
                                    <option value="Seed">Seed</option>
                                    <option value="Agro Chemical">Agro Chemical</option>
                                    <option value="Fertilizers">Fertilizers</option>
                                    <option value="Agro Implements">Agro Implements</option>
                                    <option value="Others">Others</option>
                                </select>
                            </div>
                        
                </div>
              </div>
              <div class="row">
                
                <div class="col-md-12">
                            <div class="form-group mb-2">
                                <label for="seller">Category of seller<span class="text-danger" reuired="required">*</span></label>
                                <select id="seller" name="seller">
                                    <option value="Manufacture">Manufacture</option>
                                    <option value="Distributor">Distributor</option>
                                </select>
                            </div>
                        
                </div>
              </div>
              </div>

              <div class="row">
                  <div class="col-md-12">
                      <div class="form-group mb-2">
                          <label for="form_message">Additional Info<span class="text-danger">*</span></label>
                          <textarea id="form_info" name="form_info" class="form-control" placeholder="Add additional info" rows="4" required="required"></textarea>
                      </div>
                  </div>
                  <div class="col-md-12 mt-2">
                      <input type="submit" class="btn btn-danger btn-send " name="datasave" value="submit">
                  </div>
              </div>
          </div>
      </form>


  </div>

  </div>
  <?php include('footer.php'); ?>