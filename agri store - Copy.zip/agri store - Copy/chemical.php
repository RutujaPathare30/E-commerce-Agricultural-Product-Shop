<?php include('navbar.php'); ?>
          
    <div class="container mt-3">
        <h1 class="text-center">Chemical Pesticides</h1>
        <!-- Nav tabs -->
        
        <div class="tab-content">
            
                <div class="row">
            
                    <div class="col-md-3 col-sm-6 mb-sm-3">
                        <div class="card">
                            <img src="img/coraG.webp" class="card-img-top " style="height: 230px;" alt="..." >
                            <div class="card-body text-center">
                                <h5 class="card-title">Coragen Insecticide </h5>
                                <p>FMC</p>
                                <h6 class="card-subtitle mb-2 text-muted "><i class="fa fa-inr"></i>210/-<i class="fa fa-inr"></i><s>220</s></h6>
                                <p class="card-text ">
                                    Saved price<i class="fa fa-inr"></i>10</p>
                                    <p class="card-text ">
                                        Size:10ml</p>
                                <a class="btn btn-success" href="https://api.whatsapp.com/send?phone=9156965861&amp;"><i class="fa fa-whatsapp"></i> Order Now</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-6 mb-sm-3">
                        <div class="card">
                            <img src="img/jump.webp" class="card-img-top " style="height: 230px;" alt="..." >
                            <div class="card-body text-center">
                                <h5 class="card-title">Jump Insecticide </h5>
                                <p>Bayer</p>
                                <h6 class="card-subtitle mb-2 text-muted "><i class="fa fa-inr "></i>172/-<i class="fa fa-inr"></i><s>240</s></h6>
                                <p class="card-text ">
                                    Saved price <i class="fa fa-inr"></i>68</p>
                                    <p class="card-text ">
                                        Size:40gm</p>
                                <a class="btn btn-success" href="https://api.whatsapp.com/send?phone=9156965861&amp;"><i class="fa fa-whatsapp"></i> Order Now</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-6 mb-sm-3">
                        <div class="card">
                            <img src="img/em.webp" class="card-img-top " style="height: 200px;" alt="..." >
                            <div class="card-body text-center">
                                <h5 class="card-title">EM 1 Insecticide</h5>
                                <p>Dhanuka</p>
                                <h6 class="card-subtitle mb-2 text-muted "><i class="fa fa-inr "></i>243/-<i class="fa fa-inr"></i><s>300</s></h6>
                                <p class="card-text ">
                                    Saved price <i class="fa fa-inr"></i>57</p>
                                    <p class="card-text ">
                                        Size :100gm</p>
                                <a class="btn btn-success" href="https://api.whatsapp.com/send?phone=9156965861&amp;"><i class="fa fa-whatsapp"></i> Order Now</a>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-md-3 col-sm-6 mb-sm-3">
                        <div class="card">
                            <img src="img/Antracol.webp" class="card-img-top " style="height: 200px;" alt="..." >
                            <div class="card-body text-center">
                                <h5 class="card-title">ANTRACOL FUNGICIDE</h5>
                                <p>Bayer</p>
                                <h6 class="card-subtitle mb-2 text-muted "><i class="fa fa-inr "></i>249/-<i class="fa fa-inr"></i><s>350</s></h6>
                                <p class="card-text ">
                                    Saved price <i class="fa fa-inr"></i>101</p>
                                    <p class="card-text ">
                                        Size:250gm</p>
                                <a class="btn btn-success" href="https://api.whatsapp.com/send?phone=9156965861&amp;"><i class="fa fa-whatsapp"></i> Order Now</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-6 mb-sm-3">
                        <div class="card">
                            <img src="img/Saaf.webp" class="card-img-top " style="height: 200px;" alt="..." >
                            <div class="card-body text-center">
                                <h5 class="card-title">SAAF FUNGICIDE</h5>
                                <p>UPL</p>
                                <h6 class="card-subtitle mb-2 text-muted "><i class="fa fa-inr "></i>99/-<i class="fa fa-inr"></i><s>111</s></h6>
                                <p class="card-text ">
                                    Saved price <i class="fa fa-inr"></i>12</p>
                                    <p class="card-text ">
                                        Size:100GMS</p>
                                <a class="btn btn-success" href="https://api.whatsapp.com/send?phone=9156965861&amp;"><i class="fa fa-whatsapp"></i> Order Now</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-6 mb-sm-3">
                        <div class="card">
                            <img src="img/bluecopper.webp" class="card-img-top " style="height: 200px;" alt="..." >
                            <div class="card-body text-center">
                                <h5 class="card-title">BLUE COPPER FUNGICIDE</h5>
                                <p>Crystal Crop Protection</p>
                                <h6 class="card-subtitle mb-2 text-muted "><i class="fa fa-inr "></i>439/-<i class="fa fa-inr"></i><s>725</s></h6>
                                <p class="card-text ">
                                    Saved price <i class="fa fa-inr"></i>286</p>
                                    <p class="card-text ">
                                        Size:500GM</p>
                                <a class="btn btn-success" href="https://api.whatsapp.com/send?phone=9156965861&amp;"><i class="fa fa-whatsapp"></i> Order Now</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-6 mb-sm-3">
                        <div class="card">
                            <img src="img/goal.webp" class="card-img-top " style="height: 200px;" alt="..." >
                            <div class="card-body text-center">
                                <h5 class="card-title">GLYCEL HERBICIDE</h5>
                                <p>Sumitomo</p>
                                <h6 class="card-subtitle mb-2 text-muted "><i class="fa fa-inr "></i>611/-<i class="fa fa-inr"></i><s>815</s></h6>
                                <p class="card-text ">
                                    Saved price <i class="fa fa-inr"></i>204</p>
                                    <p class="card-text ">
                                        Size:1LTR</p>
                                <a class="btn btn-success" href="https://api.whatsapp.com/send?phone=9156965861&amp;"><i class="fa fa-whatsapp"></i> Order Now</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-6 mb-sm-3">
                        <div class="card">
                            <img src="img/agil.webp" class="card-img-top " style="height: 200px;" alt="..." >
                            <div class="card-body text-center">
                                <h5 class="card-title">AGIL HERBICIDE</h5>
                                <p>Adama</p>
                                <h6 class="card-subtitle mb-2 text-muted "><i class="fa fa-inr "></i>214/-<i class="fa fa-inr"></i><s>500</s></h6>
                                <p class="card-text ">
                                    Saved price <i class="fa fa-inr"></i>286</p>
                                    <p class="card-text ">
                                        Size:100ML</p>
                                <a class="btn btn-success" href="https://api.whatsapp.com/send?phone=9156965861&amp;"><i class="fa fa-whatsapp"></i> Order Now</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-6 mb-sm-3">
                        <div class="card">
                            <img src="img/sem.webp" class="card-img-top " style="height: 200px;" alt="..." >
                            <div class="card-body text-center">
                                <h5 class="card-title">SEMPRA HERBICIDE</h5>
                                <p>Dhanuka</p>
                                <h6 class="card-subtitle mb-2 text-muted "><i class="fa fa-inr "></i>239/-<i class="fa fa-inr"></i><s>281</s></h6>
                                <p class="card-text ">
                                    Saved price <i class="fa fa-inr"></i>42</p>
                                    <p class="card-text ">
                                        Size:3.6gm</p>
                                <a class="btn btn-success" href="https://api.whatsapp.com/send?phone=9156965861&amp;"><i class="fa fa-whatsapp"></i> Order Now</a>
                            </div>
                        </div>
                    </div>
                </div>
         </div>
            
    </div>
    <?php include('footer.php'); ?>