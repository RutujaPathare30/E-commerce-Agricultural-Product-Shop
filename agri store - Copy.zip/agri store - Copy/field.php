<?php include('navbar.php'); ?>
          
    <div class="container mt-3">
        <h1 class="text-center">Field Seed</h1>
        <!-- Nav tabs -->
        <ul class="nav nav-tabs" role="tablist">
            <li class="nav-item">
                <a class="nav-link active" data-bs-toggle="tab" href="#mobiles">Corn</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" data-bs-toggle="tab" href="#accessories">Jower </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" data-bs-toggle="tab" href="#glass">Cotton</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" data-bs-toggle="tab" href="#paddy">Paddy</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" data-bs-toggle="tab" href="#musturd">Musturd</a>
            </li>
            
        </ul>
        <!-- Tab panes -->
        <div class="tab-content">
            <div id="mobiles" class="container tab-pane active">
                <h3 class="text-center mt-2">Corn</h3>
                <div class="row">
                    <div class="col-md-3 col-sm-6 mb-sm-3">
                        <div class="card">
                            <img src="img/CORN.avif" class="card-img-top " style="height: 230px;" alt="..." >
                            <div class="card-body text-center">
                                <h5 class="card-title">PIONEER AGRO CORN SEED/ MAIZE SEED </h5>
                                <p>Pioneer Agro</p>
                                <h6 class="card-subtitle mb-2 text-muted "><i class="fa fa-inr"></i>578/-<i class="fa fa-inr"></i><s>751</s></h6>
                                <p class="card-text ">
                                    Saved price<i class="fa fa-inr"></i>173</p>
                                    <p class="card-text ">
                                        Size:1kg</p>
                                <a class="btn btn-success" href="https://api.whatsapp.com/send?phone=9156965861&amp;"><i class="fa fa-whatsapp"></i> Order Now</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-6 mb-sm-3">
                        <div class="card">
                            <img src="img/field-crops-dekalb-9108-corn.png" class="card-img-top " style="height: 230px;" alt="..." >
                            <div class="card-body text-center">
                                <h5 class="card-title">DEKALB 9108 CORN </h5>
                                <p>Dekalb</p>
                                <h6 class="card-subtitle mb-2 text-muted "><i class="fa fa-inr "></i>2000/-<i class="fa fa-inr"></i><s>2500</s></h6>
                                <p class="card-text ">
                                    Saved price <i class="fa fa-inr"></i>500</p>
                                    <p class="card-text ">
                                        Size:4.5kg</p>
                                <a class="btn btn-success" href="https://api.whatsapp.com/send?phone=9156965861&amp;"><i class="fa fa-whatsapp"></i> Order Now</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-6 mb-sm-3">
                        <div class="card">
                            <img src="img/P3546-LUMIGEN-CORN.jpg" class="card-img-top " style="height: 200px;" alt="..." >
                            <div class="card-body text-center">
                                <h5 class="card-title">LUMIGEN P3546 CORN</h5>
                                <p>DuPont Pioneer</p>
                                <h6 class="card-subtitle mb-2 text-muted "><i class="fa fa-inr "></i>1840/-<i class="fa fa-inr"></i><s>2000</s></h6>
                                <p class="card-text ">
                                    Saved price <i class="fa fa-inr"></i>160</p>
                                    <p class="card-text ">
                                        Size :4kg</p>
                                <a class="btn btn-success" href="https://api.whatsapp.com/send?phone=9156965861&amp;"><i class="fa fa-whatsapp"></i> Order Now</a>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-md-3 col-sm-6 mb-sm-3">
                        <div class="card">
                            <img src="img/8225.webp" class="card-img-top " style="height: 200px;" alt="..." >
                            <div class="card-body text-center">
                                <h5 class="card-title">8255 CORN</h5>
                                <p>Dhaanya</p>
                                <h6 class="card-subtitle mb-2 text-muted "><i class="fa fa-inr "></i>1100/-<i class="fa fa-inr"></i><s>1200</s></h6>
                                <p class="card-text ">
                                    Saved price <i class="fa fa-inr"></i>100</p>
                                    <p class="card-text ">
                                        Size:4kg</p>
                                <a class="btn btn-success" href="https://api.whatsapp.com/send?phone=9156965861&amp;"><i class="fa fa-whatsapp"></i> Order Now</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-6 mb-sm-3">
                        <div class="card">
                            <img src="img/ROBUST-CORN-SEEDS.jpg" class="card-img-top " style="height: 200px;" alt="..." >
                            <div class="card-body text-center">
                                <h5 class="card-title">ROBUST CORN SEEDS</h5>
                                <p>Foragen Seeds
                                </p>
                                <h6 class="card-subtitle mb-2 text-muted "><i class="fa fa-inr "></i>750/-<i class="fa fa-inr"></i><s>800</s></h6>
                                <p class="card-text ">
                                    Saved price <i class="fa fa-inr"></i>50</p>
                                    <p class="card-text ">
                                        Size:2000Seeds</p>
                                <a class="btn btn-success" href="https://api.whatsapp.com/send?phone=9156965861&amp;"><i class="fa fa-whatsapp"></i> Order Now</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-6 mb-sm-3">
                        <div class="card">
                            <img src="img/shine.avif" class="card-img-top " style="height: 200px;" alt="..." >
                            <div class="card-body text-center">
                                <h5 class="card-title">RISE AGRO RISE-303 SHINE HYBRID MAIZE SEEDS</h5>
                                <p>Rise Agro</p>
                                <h6 class="card-subtitle mb-2 text-muted "><i class="fa fa-inr "></i>1572/-<i class="fa fa-inr"></i><s>1750</s></h6>
                                <p class="card-text ">
                                    Saved price <i class="fa fa-inr"></i>178</p>
                                    <p class="card-text ">
                                        Size:4kg</p>
                                <a class="btn btn-success" href="https://api.whatsapp.com/send?phone=9156965861&amp;"><i class="fa fa-whatsapp"></i> Order Now</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-6 mb-sm-3">
                        <div class="card">
                            <img src="img/nk.avif" class="card-img-top " style="height: 200px;" alt="..." >
                            <div class="card-body text-center">
                                <h5 class="card-title">SYNGENTA NK 6240 MAIZE SEEDS</h5>
                                <p>Syngenta</p>
                                <h6 class="card-subtitle mb-2 text-muted "><i class="fa fa-inr "></i>1440/-<i class="fa fa-inr"></i><s>1600</s></h6>
                                <p class="card-text ">
                                    Saved price <i class="fa fa-inr"></i>160</p>
                                    <p class="card-text ">
                                        Size:4kg</p>
                                <a class="btn btn-success" href="https://api.whatsapp.com/send?phone=9156965861&amp;"><i class="fa fa-whatsapp"></i> Order Now</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-6 mb-sm-3">
                        <div class="card">
                            <img src="img/Advanta-Hybrid-Corn-PAC-751.jpg" class="card-img-top " style="height: 200px;" alt="..." >
                            <div class="card-body text-center">
                                <h5 class="card-title">PAC 751 HYBRID CORN</h5>
                                <p>Advanta</p>
                                <h6 class="card-subtitle mb-2 text-muted "><i class="fa fa-inr "></i>1300/-<s><i class="fa fa-inr"></i>1500</s></h6>
                                <p class="card-text ">
                                    Saved price <i class="fa fa-inr"></i>200</p>
                                    <p class="card-text ">
                                        Size:4kg</p>
                                <a class="btn btn-success" href="https://api.whatsapp.com/send?phone=9156965861&amp;"><i class="fa fa-whatsapp"></i> Order Now</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div id="accessories" class="container tab-pane fade">
                <h3 class="text-center">Jower Seed</h3>
                <div class="row">
                <div class="col-md-3 col-sm-6 mb-sm-3">
                    <div class="card">
                        <img src="img/3206-Hytechseeds-Jowar.avif" class="card-img-top " style="height: 200px;" alt="..." >
                        <div class="card-body text-center">
                            <h5 class="card-title">3206 JOWAR (SORGHUM) </h5>
                            <p>Hytech</p>
                            <h6 class="card-subtitle mb-2 text-muted "><i class="fa fa-inr "></i>790/-<s><i class="fa fa-inr"></i>820</s></h6>
                            <p class="card-text ">
                                Saved price <i class="fa fa-inr"></i>30</p>
                                <p class="card-text ">
                                    Size:3kg</p>
                            <a class="btn btn-success" href="https://api.whatsapp.com/send?phone=9156965861&amp;"><i class="fa fa-whatsapp"></i> Order Now</a>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 col-sm-6 mb-sm-3">
                    <div class="card">
                        <img src="img/PAC_501-Advanta-Jowar.avif" class="card-img-top " style="height: 200px;" alt="..." >
                        <div class="card-body text-center">
                            <h5 class="card-title">PAC 501 JOWAR</h5>
                            <p>Advanta</p>
                            <h6 class="card-subtitle mb-2 text-muted "><i class="fa fa-inr "></i>600/-<i class="fa fa-inr"></i><s>650</s></h6>
                            <p class="card-text ">
                                Saved price <i class="fa fa-inr"></i>50</p>
                                <p class="card-text ">
                                    Size:3kg</p>
                            <a class="btn btn-success" href="https://api.whatsapp.com/send?phone=9156965861&amp;"><i class="fa fa-whatsapp"></i> Order Now</a>
                        </div>
                    </div>
                </div>
                
            </div>
            </div>
            <div id="glass" class="container tab-pane fade">
                <h3 class="text-center">Cotton Seed</h3>
                <div class="row">
               
                    <div class="col-md-3 col-sm-6 mb-sm-3">
                        <div class="card">
                            <img src="img/rch.jpg" class="card-img-top " style="height: 200px;" alt="..." >
                            <div class="card-body text-center">
                                <h5 class="card-title">RCH 659 BG II COTTON</h5>
                                <p>Rasi Seeds</p>
                                <h6 class="card-subtitle mb-2 text-muted "><i class="fa fa-inr "></i>853/-</h6>
                                
                                    <p class="card-text ">
                                        Size:450gm</p>
                                <a class="btn btn-success" href="https://api.whatsapp.com/send?phone=9156965861&amp;"><i class="fa fa-whatsapp"></i> Order Now</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-6 mb-sm-3">
                        <div class="card">
                            <img src="img/us.webp" class="card-img-top " style="height: 200px;" alt="..." >
                            <div class="card-body text-center">
                                <h5 class="card-title">US 7067 BG II (SWCH 4749 BG II) COTTON</h5>
                                <p>US Agri</p>
                                <h6 class="card-subtitle mb-2 text-muted "><i class="fa fa-inr "></i>853/-</h6>
                                
                                    <p class="card-text ">
                                        Size:475gm</p>
                                <a class="btn btn-success" href="https://api.whatsapp.com/send?phone=9156965861&amp;"><i class="fa fa-whatsapp"></i> Order Now</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-6 mb-sm-3">
                        <div class="card">
                            <img src="img/CCH_999.jpg" class="card-img-top " style="height: 200px;" alt="..." >
                            <div class="card-body text-center">
                                <h5 class="card-title">CCH 999 BG II HYBRID COTTON</h5>
                                <p>Crystal Crop Protection</p>
                                <h6 class="card-subtitle mb-2 text-muted "><i class="fa fa-inr "></i>853/-</h6>
                                
                                    <p class="card-text ">
                                        Size:475gm</p>
                                <a class="btn btn-success" href="https://api.whatsapp.com/send?phone=9156965861&amp;"><i class="fa fa-whatsapp"></i> Order Now</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-6 mb-sm-3">
                        <div class="card">
                            <img src="img/MAHYCOJUNGEECOTTON.jpg" class="card-img-top " style="height: 200px;" alt="..." >
                            <div class="card-body text-center">
                                <h5 class="card-title">MAHYCO JUNGEE COTTON</h5>
                                <p>Mahyco
                                </p>
                                <h6 class="card-subtitle mb-2 text-muted "><i class="fa fa-inr "></i>853/-</h6>
                                
                                    <p class="card-text ">
                                        Size:475gm</p>
                                <a class="btn btn-success" href="https://api.whatsapp.com/send?phone=9156965861&amp;"><i class="fa fa-whatsapp"></i> Order Now</a>
                            </div>
                        </div>
                    </div>
                    
                </div>
            </div>
            <div id="paddy" class="container tab-pane fade">
                <h3 class="text-center">Paddy Seed</h3>
                <div class="row">
                    
                    <div class="col-md-3 col-sm-6 mb-sm-3">
                        <div class="card">
                            <img src="img/pac8.avif" class="card-img-top " style="height: 200px;" alt="..." >
                            <div class="card-body text-center">
                                <h5 class="card-title">PAC837 HYBRID PADDY (RICE)</h5>
                                <p>Advanta</p>
                                <h6 class="card-subtitle mb-2 text-muted "><i class="fa fa-inr "></i>9500/-</h6>
                                
                                    <p class="card-text ">
                                        Size:30kg</p>
                                <a class="btn btn-success" href="https://api.whatsapp.com/send?phone=9156965861&amp;"><i class="fa fa-whatsapp"></i> Order Now</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-6 mb-sm-3">
                        <div class="card">
                            <img src="img/Bioseed-Paddy-799.avif" class="card-img-top " style="height: 200px;" alt="..." >
                            <div class="card-body text-center">
                                <h5 class="card-title">BIOSEED HYBRID PADDY 799</h5>
                                <p>Bioseed</p>
                                <h6 class="card-subtitle mb-2 text-muted "><i class="fa fa-inr "></i>1710/-</h6>
                                
                                    <p class="card-text ">
                                        Size:6kg</p>
                                <a class="btn btn-success" href="https://api.whatsapp.com/send?phone=9156965861&amp;"><i class="fa fa-whatsapp"></i> Order Now</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-6 mb-sm-3">
                        <div class="card">
                            <img src="img/pac33.avif" class="card-img-top " style="height: 200px;" alt="..." >
                            <div class="card-body text-center">
                                <h5 class="card-title">PAC 8744 ADVANTA HYBRID PADDY (RICE)</h5>
                                <p>Advanta</p>
                                <h6 class="card-subtitle mb-2 text-muted "><i class="fa fa-inr "></i>9500/-</h6>
                                
                                    <p class="card-text ">
                                        Size:30kg</p>
                                <a class="btn btn-success" href="https://api.whatsapp.com/send?phone=9156965861&amp;"><i class="fa fa-whatsapp"></i> Order Now</a>
                            </div>
                        </div>
                    </div>
                    
                    
                </div>
            </div>
            <div id="musturd" class="container tab-pane fade">
                <h3 class="text-center">Musturd Seed</h3>
                <div class="row">
                    
                    <div class="col-md-3 col-sm-6 mb-sm-3">
                        <div class="card">
                            <img src="img/total.webp" class="card-img-top " style="height: 200px;" alt="..." >
                            <div class="card-body text-center">
                                <h5 class="card-title">TOTAL 520 - IMPROVED BLACK MUSTARD SEEDS</h5>
                                <p>Genuine</p>
                                <h6 class="card-subtitle mb-2 text-muted "><i class="fa fa-inr "></i>595/-</h6>
                                
                                    <p class="card-text ">
                                        Size:1kg</p>
                                <a class="btn btn-success" href="https://api.whatsapp.com/send?phone=9156965861&amp;"><i class="fa fa-whatsapp"></i> Order Now</a>
                            </div>
                        </div>
                    </div>
                    
                    
                    
                </div>
            </div>
            
        </div>
    </div>
    <?php include('footer.php'); ?>