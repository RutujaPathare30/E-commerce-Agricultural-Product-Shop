<!DOCTYPE php>
<php lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AgriStore</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js" integrity="sha384-7+zCNj/IqJ95wo16oMtfsKbZ9ccEh31eOz1HGyDuCQ6wgnyJNSYdrPa03rtR1zdB" crossorigin="anonymous"></script>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@500&display=swap" rel="stylesheet">
    <script src="js/bootstrap.bundle.min.js"></script>
</head>
<body>

    <div class="container-fluid">
      <nav class="navbar navbar-expand-lg navbar-dark text-white bg-black  ">
        <div class="collapse navbar-collapse " id="navbarNavDropdown">
            <ul class="navbar-nav">
                
              
              <li class="nav-item" style="margin-left: 600px;">
                <a class="nav-link text-white" href="sell.php">Sell on Agro</a>
              </li>
              <li class="nav-item " style="margin-left: 10px;" >
                <a class="nav-link text-white" href="bulk.php">Bulk Order Inquiries
                </a>
              </li>
              <li class="nav-item" style="margin-left: 10px; " >
                <a class="nav-link text-white" href="tel:9156965861">Missed call To Order-8668876041
                </a>
              </li>
              
              
              
            </ul>
        </div>


      </nav>
    </div>

   
  <div class="container-fluid  ">
          <nav class="navbar navbar-expand-lg navbar-light text-dark bg-light sticky-top">
          <img src="img/agro.jpg" style="height:100px;" >
          <a class="navbar-brand  " href="index.php" ></a>
          
         
      
      
        <div class="collapse navbar-collapse " id="navbarNavDropdown">
            <ul class="navbar-nav">
                <li class="nav-item dropdown " style="margin-right: 40px;">
                    <a class="nav-link dropdown-toggle text-dark" href="#" id="navbarDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                      Crop Protection
                    </a>
                    <ul class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                      <li><a class="dropdown-item" href="chemical.php">Chemical</a></li>
                      <li><a class="dropdown-item" href="organic.php">Oraganic</a></li>
                      
                    
                      
                    </ul>
                  </li>
                  <li class="nav-item dropdown " style="margin-right: 40px;">
                    <a class="nav-link dropdown-toggle text-dark" href="#" id="navbarDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                      Seeds
                    </a>
                    <ul class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                      <li><a class="dropdown-item" href="holti.php">Holticulture crop</a></li>
                      <li><a class="dropdown-item" href="field.php">Field Crop</a></li>
                      
                    
                      
                    </ul>
                  </li>
                
              
                 <li class="nav-item" style="margin-right: 40px;">
                <a class="nav-link text-dark " href="blog.php">Blog</a>
                 </li>
                 <li class="nav-item" style="margin-right: 40px;">
                  <a class="nav-link text-dark " href="offer.php">Offers</a>
                   </li>
              
                 <li class="nav-item" style="margin-right: 500px; " >
                  <a class="nav-link text-dark " href="contact.php">ContactUs
                 </a>
                </li>
              
              
              
            </ul>
      </div>
          </nav>
        </div>