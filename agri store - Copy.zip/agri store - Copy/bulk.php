<?php include('navbar.php'); ?>
          

          
          <div class="container-fluid mt-lg-4  " style="align-content: centers;">
    
            <div class="col-md-12 col-sm-12  rounded-3  " >
              <h3 class="text-center">Bulk Order Inquiries</h3>
              <hr style="margin-left: 300px; margin-right: 300px;">
              <h4 class="text-center">Please fill the form and we will call you back</h4>
              <form method="post" action="bulksave.php"  style="margin-left: 350px; margin-right: 320px;">
                  <div class="messages"></div>
                  <div class="controls">
                      <div class="row">
                          <div class="col-md-6">
                              <div class="form-group mb-2">
                                  <label for="form_name">Firstname <span class="text-danger">*</span></label>
                                  <input id="form_name" type="text" name="form_name" class="form-control" placeholder="Firstname" required="">
                              </div>
                          </div>
                          <div class="col-md-6">
                              <div class="form-group mb-2">
                                  <label for="form_lastname">Last name<span class="text-danger">*</span></label>
                                  <input id="form_lastname" type="text" name="form_lastname" class="form-control" placeholder="Lastname" required="">
                              </div>
                          </div>
                      </div>
                      <div class="row ">
                          <div class="col-md-6">
                              <div class="form-group mb-2">
                                  <label for="form_EmailID">Email<span class="text-danger">*</span></label>
                                  <input id="form_EmailID" type="email" name="form_EmailID" class="form-control" placeholder="email" required="">
                              </div>
                          </div>
                          <div class="col-md-6">
                              <div class="form-group mb-2">
                                  <label for="form_phone">Phone</label>
                                  <input id="form_phone" type="tel" name="form_phone" class="form-control" placeholder="phone">
                              </div>
                          </div>
                          
                      </div>
                      <div class="row">
                        <div class="col-md-12">
                            <div class="form-group mb-2">
                                <label for="form_address">Address<span class="text-danger">*</span></label>
                                <input id="form_address" name="form_address" class="form-control" placeholder="address" rows="4" required="required">
                            </div>
                        </div>
                      </div>
                      <div class="row">
                        <div class="col-md-12">
                            <div class="form-group mb-2">
                                <label for="user">User type<span class="text-danger">*</span></label>
                                <select id="user" name="user">
                                    <option value="Farmer">Farmer</option>
                                    <option value="Dealer">Dealer</option>
                                </select>
                            </div>
                        </div>
                      </div>
                      <div class="row">
                        <div class="col-md-12">
                            <div class="form-group mb-2">
                                <label for="form_address">Product Name<span class="text-danger">*</span></label>
                                <textarea id="form_product" name="form_product" class="form-control" placeholder="Product name" rows="4" required="required"></textarea>
                            </div>
                        </div>
                      </div>
                      
                      
                      
                      </div>
        
                      <div class="row">
                          <div class="col-md-12">
                              <div class="form-group mb-2">
                                  <label for="form_message">Additional Info<span class="text-danger">*</span></label>
                                  <textarea id="form_info" name="form_info" class="form-control" placeholder="Add additional info" rows="4" required="required"></textarea>
                              </div>
                          </div>
                          <div class="col-md-12 mt-2">
                              <input type="submit" class="btn btn-danger btn-send " name="datasave" value="submit">
                          </div>
                      </div>
                  </div>
              </form>
        
        
          </div>
          <?php include('footer.php'); ?>